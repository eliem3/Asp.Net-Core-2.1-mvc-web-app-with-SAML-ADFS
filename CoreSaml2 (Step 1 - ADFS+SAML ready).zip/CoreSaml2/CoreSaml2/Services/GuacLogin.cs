﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreSaml2.Models;
using CoreSaml2.Layers;

namespace CoreSaml2.Services
{
    public class GuacLogin
    {
        private GuacaMoel.guacamole_dbModel model = new GuacaMoel.guacamole_dbModel();
        /// <summary>
        /// Display the list of All Entity Name
        /// </summary>
        /// <returns></returns>
        public List<GuacaMoel.GuacamoleEntity> GetAllUserList()
        {
            using (GuacaMoel.guacamole_dbModel db = new GuacaMoel.guacamole_dbModel())
            {
                var result = (from entity in db.GuacamoleEntities
                              select entity).ToList();
                return result;
            }
        }

        /// <summary>
        /// Display all User's Details
        /// </summary>
        /// <returns></returns>
        public List<GuacaMoel.GuacamoleUser> GetUsers()
        {
            using (GuacaMoel.guacamole_dbModel db = new GuacaMoel.guacamole_dbModel())
            {
                var result = (from usr in db.GuacamoleUsers
                              select usr).ToList();
                return result;
            }
        }

        /// <summary>
        /// Show all the Personel with Login Access from Database
        /// </summary>
        /// <returns></returns>
        public List<Personel> ListOfAllPersonel()
        {
            var enty = model.GuacamoleEntities.ToList();
            var usr = model.GuacamoleUsers.ToList();

            var result = (from al in enty
                          join ur in usr on al.EntityId equals ur.EntityId
                          select new Personel
                          {
                              Id = al.EntityId,
                              username = al.Name,
                              //hashpassword = ur.PasswordHash.ToString()
                          }).ToList();
            return result;
        }

        /// <summary>
        /// Login Signle Personel into the System with same credentials as Guacamole Database
        /// </summary>
        /// <param name="user">username</param>
        /// <param name="pass">password</param>
        /// <returns></returns>
        public Personel LogSingPersonel(string user, string pass)
        {
            using (GuacaMoel.guacamole_dbModel db = new GuacaMoel.guacamole_dbModel())
            {
                var entity = db.GuacamoleEntities.ToList(); //return Solo //.Where(x => x.name == user).Tolist();
                var usr = db.GuacamoleUsers.ToList();

                var result = (from en in entity
                              join ur in usr on en.EntityId equals ur.EntityId
                              select new Personel
                              {

                                  Id = en.EntityId,
                                  username = en.Name,
                                  //hashpassword = ur.PasswordHash
                              }).FirstOrDefault();
                return result;
            }
        }

    }
}
