﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CoreSaml2.Models;
using Microsoft.AspNetCore.Authorization;
using CoreSaml2.Services;
using Microsoft.AspNetCore.Authentication;

namespace CoreSaml2.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        public IActionResult SignIn(string returnUrl)
        {
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Home");
            }

            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SignIn(string username, string password, string returnurl)
        {
            GuacLogin sign = new GuacLogin();

            if (sign.LogSingPersonel(username, password) != null)
            {
                HttpContext.SignInAsync(username, null);
                if (!string.IsNullOrEmpty(returnurl))
                {
                    return Redirect(returnurl);
                }
                else
                {
                    ViewBag.Myusername = username;
                    return RedirectToAction("Index", "Home");
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid Login Credentials, please try again!");
                ViewBag.ReturnUrl = returnurl;
                return View();
            }

        }

        public IActionResult SignOut()
        {
            if (User.Identity.IsAuthenticated) //if user is authenticate using AD
            {
                return RedirectToAction("Logout", "Account");
            }
            else // if user is authenticate using local Database
            {
                HttpContext.Session.Clear();
                HttpContext.SignOutAsync();
                return RedirectToAction("SignIn", "Home");
            }
            
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
